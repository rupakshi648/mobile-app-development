package com.hyg.awesome.familymobiletracker.feature.Utilities;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hyg.awesome.familymobiletracker.feature.Interfaces.VolleyCallback;
import com.hyg.awesome.familymobiletracker.feature.Models.ContactModel;
import com.hyg.awesome.familymobiletracker.feature.Models.HelpLineModel;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class DataProvider {
    private static SharedPreferences sharedPreferences;
    private static Location currentLocation;
    private static Activity activity;
    private static Context context;
    private static StringRequest stringRequest;
    private static RequestQueue queue;

    public static void init(Activity activity) {
        context = activity;
        DataProvider.activity = activity;
        sharedPreferences = context.getSharedPreferences("info.txt", Context.MODE_PRIVATE);
        queue= Volley.newRequestQueue(activity);
    }

    public static void storeLocationIfo(Location location) {
        currentLocation = location;


        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("latitude", String.valueOf(location.getLatitude()));
        editor.putString("longitude", String.valueOf(location.getLongitude()));
        editor.apply();

    }

    public static Location getCurrentLocation() {
        return currentLocation;
    }

    public static void storeEmergencyContacts(ArrayList<ContactModel> contacts) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String contactsJSON = gson.toJson(contacts);
        editor.putString("contacts", contactsJSON);
        editor.apply();
    }

    public static ArrayList<ContactModel> getEmergencyContacts() {
        String contactsJSON = sharedPreferences.getString("contacts", "null");
        Gson gson = new Gson();
        ArrayList<ContactModel> contacts = gson.fromJson(contactsJSON, new TypeToken<List<ContactModel>>() {
        }.getType());
//        Log.d("chech", contacts.size() + "");
        if(contacts==null){
            contacts = new ArrayList<ContactModel>();
        }
        return contacts;
    }

    public static ArrayList<HelpLineModel> getHelplines() {
        ArrayList<HelpLineModel> helplines = new ArrayList<HelpLineModel>();
        helplines.add(new HelpLineModel("Canadian Women's Foundation", "18662934483"));
        helplines.add(new HelpLineModel("Assaulted Women's Helpline", "18668630511"));
        helplines.add(new HelpLineModel("Calgary Women's Emergency Shelter", "18666067233"));
        helplines.add(new HelpLineModel("Woods Home", "4032999699"));
        return helplines;
    }

    public static void getJSONFromURL(final VolleyCallback callback, String url){
        Response.Listener<String> responseListener =new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                callback.onSuccess(response);
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("chech",error.toString());
            }
        };
        stringRequest=new StringRequest(Request.Method.GET, url, responseListener, errorListener);
        queue.add(stringRequest);
    }

    public static void storeLoginInfo(String mobileNumber) {
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean("isLoggedIn",true);
        editor.putString("mobile",mobileNumber);
        editor.apply();
    }
    public static boolean isLoggedIn() {
        return sharedPreferences.getBoolean("isLoggedIn",false);
    }

    public static String getUserInfo() {
        return sharedPreferences.getString("mobile","");
    }


    public static void logout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}

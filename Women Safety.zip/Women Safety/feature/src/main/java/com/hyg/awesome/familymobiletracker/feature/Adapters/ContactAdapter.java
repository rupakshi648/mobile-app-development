package com.hyg.awesome.familymobiletracker.feature.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;


import com.hyg.awesome.familymobiletracker.feature.Models.ContactModel;
import com.hyg.awesome.familymobiletracker.feature.R;
import com.hyg.awesome.familymobiletracker.feature.Utilities.DataProvider;

import java.util.ArrayList;
import java.util.List;

public class ContactAdapter extends ArrayAdapter<ContactModel> {
    ArrayList<ContactModel> items;
    public ContactAdapter(Context context, int resource, ArrayList<ContactModel> items) {
        super(context, resource);
        this.items = items;
    }
    @Override
    public int getCount() {
        return items.size();
    }
    @Override
    public ContactModel getItem(int position) {
        return items.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(getContext());
            v = vi.inflate(R.layout.layout_contact, null);
        }

        final ContactModel contact = getItem(position);

        if (contact != null) {
            TextView name=v.findViewById(R.id.tvContactName);
            TextView number=v.findViewById(R.id.tvNumber);
            ImageButton delete=v.findViewById(R.id.delete);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    items.remove(contact);
                    DataProvider.storeEmergencyContacts(items);
                    notifyDataSetChanged();
                }
            });
            name.setText(contact.getName());
            number.setText(contact.getContactNumber());

        }

        return v;
    }
    public void updateDataSet(ArrayList<ContactModel> items){
        this.items = items;
        this.notifyDataSetChanged();
    }

}

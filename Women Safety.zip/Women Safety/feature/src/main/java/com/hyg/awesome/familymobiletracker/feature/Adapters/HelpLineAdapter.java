package com.hyg.awesome.familymobiletracker.feature.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.hyg.awesome.familymobiletracker.feature.Models.HelpLineModel;
import com.hyg.awesome.familymobiletracker.feature.R;

import java.util.ArrayList;

public class HelpLineAdapter extends ArrayAdapter<HelpLineModel> {
    private int resource;
    private Context context;
    private ArrayList<HelpLineModel> items;

    public HelpLineAdapter(@NonNull Context context, int resource, @NonNull ArrayList<HelpLineModel> items) {
        super(context, resource, items);
        this.context = context;
        this.items=items;
        this.resource = resource;
    }
    @Override
    public int getCount() {
        return items.size();
    }
    @Override
    public HelpLineModel getItem(int position) {
        return items.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(getContext());
            v = vi.inflate(resource, null);
        }

        HelpLineModel helpline = getItem(position);

        if (helpline != null) {
            final String contact=helpline.getContact();

            TextView name=v.findViewById(R.id.tvHelplineName);
//            TextView number=v.findViewById(R.id.tvNumber);
            name.setText(helpline.getName());

//            number.setText(helpline.getContact());
            ImageButton ibCall=v.findViewById(R.id.ibCall);
            ibCall.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    initiateCall(contact);
                }
            });
        }

        return v;
    }

    private void initiateCall(String contact) {
        //Make a call here
        Intent phone_intent
                = new Intent(Intent.ACTION_DIAL);

        // Set data of Intent through Uri
        // by parsing phone number
        phone_intent
                .setData(Uri.parse("tel:"
                        + contact));

        // start Intent
        context.startActivity(phone_intent);
    }

    public void updateDataSet(ArrayList<HelpLineModel> items){
        this.items = items;
        this.notifyDataSetChanged();
    }

}


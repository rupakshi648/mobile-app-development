package com.hyg.awesome.familymobiletracker.feature.Models;

public class GroupModel {
    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    int photo;

    public int getGnom() {
        return Gnom;
    }

    public void setGnom(int Gnom) {
        this.Gnom = Gnom;
    }

    int Gnom;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    String groupName;

    public int getGroupId() {
        return GroupId;
    }

    public void setGroupId(int groupId) {
        GroupId = groupId;
    }

    int GroupId;
}

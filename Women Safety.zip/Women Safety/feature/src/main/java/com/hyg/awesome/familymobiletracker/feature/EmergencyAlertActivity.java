package com.hyg.awesome.familymobiletracker.feature;


import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hyg.awesome.familymobiletracker.feature.Models.ContactModel;
import com.hyg.awesome.familymobiletracker.feature.Utilities.DataProvider;
import com.hyg.awesome.familymobiletracker.feature.Utilities.SystemUtilities;

public class EmergencyAlertActivity extends AppCompatActivity {
    ImageView ivAlertButton;
    Button btnEmergencyContactList,btnHelpline,btnLocationSharingSettings;
    LocationCallback locationCallback;
    String server,userid;
    FloatingActionButton logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_alert);
        server=getIntent().getStringExtra("server");
        userid=getIntent().getStringExtra("userid");

        DataProvider.init(this);
        SystemUtilities.getPermissions(this);
        locationCallback=new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                super.onLocationResult(locationResult);
            }
        };
        SystemUtilities.locationInit(this,locationCallback);
        checkForEmergencyContacts();


        btnHelpline=findViewById(R.id.btnHelpLines);
        ivAlertButton=findViewById(R.id.ivAlertButton);
        btnEmergencyContactList=findViewById(R.id.btnEmergencyContactList);
        btnLocationSharingSettings=findViewById(R.id.btnLocationSharingSettings);
        logout=findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataProvider.logout();
                Intent intent = new Intent(EmergencyAlertActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnLocationSharingSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmergencyAlertActivity.this,ViewGroupActivity.class);
                intent.putExtra("server",server);
                intent.putExtra("userid",userid);
                startActivity(intent);
            }
        });
        btnEmergencyContactList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEmergencyContactList();
            }
        });
        ivAlertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert();
            }
        });
        btnHelpline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(EmergencyAlertActivity.this,HelpLineActivity.class);
                intent.putExtra("server",server);
                intent.putExtra("userid",userid);
                startActivity(intent);

            }
        });

    }

    private void checkForEmergencyContacts() {
        if(DataProvider.getEmergencyContacts().size()==0){
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Reminder")
                    .setMessage("Please note that you do not have any emergency contacts added. Add some from:\nEmergency Contacts->Add Contact")
                    .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create();
            dialog.show();
        }
    }

    private void openEmergencyContactList() {
        Intent intent = new Intent(this,ContactListActivity.class);
        intent.putExtra("server",server);
        intent.putExtra("userid",userid);
        startActivity(intent);
    }

    private void alert() {
//        Location currentLocation=DataProvider.getCurrentLocation();
        if(DataProvider.getEmergencyContacts().size()==0){
            Toast.makeText(this, "No emergency contacts added. Please add some.", Toast.LENGTH_SHORT).show();
            return;
        }
        final AlertDialog alert = new AlertDialog.Builder(this)
                .setTitle("Sending Location")
                .setMessage("Please wait...")
                .create();
        alert.show();
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    Log.d("chech","Failed to get location");
                    Toast.makeText(EmergencyAlertActivity.this, "Failed to get location", Toast.LENGTH_SHORT).show();
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    // ...
                    Log.d("chech","Got location");
//                    Toast.makeText(EmergencyAlertActivity.this, "Got location", Toast.LENGTH_SHORT).show();

                    Toast.makeText(EmergencyAlertActivity.this, "Alerted!" , Toast.LENGTH_SHORT).show();
                    SmsManager smsManager = SmsManager.getDefault();
                    for(ContactModel contact:DataProvider.getEmergencyContacts()) {
                        smsManager.sendTextMessage
                                (contact.getContactNumber(), null, "I'm in danger. Please Help!\nMy current location:\nhttps://www.google.com/maps/search/?api=1&query="+location.getLatitude()+","+location.getLongitude(),
                                        null, null);
                    }
                    alert.dismiss();

                    DataProvider.storeLocationIfo(location);
                    SystemUtilities.stopLocationUpdates(locationCallback);

                }
            }
        };
        SystemUtilities.locationInit(this,locationCallback);

//        if(currentLocation==null){
//            Toast.makeText(this, "Waiting to get location", Toast.LENGTH_SHORT).show();
//        }else {
//        }
//        SystemUtilities.startLocationUpdates();


    }
}

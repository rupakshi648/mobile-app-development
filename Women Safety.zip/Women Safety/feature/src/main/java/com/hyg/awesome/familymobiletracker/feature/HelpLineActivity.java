package com.hyg.awesome.familymobiletracker.feature;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;


import com.hyg.awesome.familymobiletracker.feature.Adapters.HelpLineAdapter;
import com.hyg.awesome.familymobiletracker.feature.Models.HelpLineModel;
import com.hyg.awesome.familymobiletracker.feature.Utilities.DataProvider;

import java.util.ArrayList;

public class HelpLineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_line);
        ListView lvHelplines=findViewById(R.id.lvHelpLines);
        ArrayList<HelpLineModel> helpLines= DataProvider.getHelplines();
        HelpLineAdapter helpLineAdapter=new HelpLineAdapter(this,R.layout.layout_helpline_item,helpLines);
        lvHelplines.setAdapter(helpLineAdapter);
    }
}
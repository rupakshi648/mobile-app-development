package com.hyg.awesome.familymobiletracker.feature.Models;

public class ContactModel {
    String name;

    public long getId() {
        return id;
    }

    long id;
    public String getName() {
        return name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    String contactNumber;
    public ContactModel(String name, String contactNumber){
        this.id=id;
        this.name=name;
        this.contactNumber=contactNumber;
    }

}

package com.hyg.awesome.familymobiletracker.feature;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import com.hyg.awesome.familymobiletracker.feature.Adapters.ContactAdapter;
import com.hyg.awesome.familymobiletracker.feature.Models.ContactModel;
import com.hyg.awesome.familymobiletracker.feature.Utilities.DataProvider;
import com.onegravity.contactpicker.contact.Contact;
import com.onegravity.contactpicker.contact.ContactDescription;
import com.onegravity.contactpicker.contact.ContactSortOrder;
import com.onegravity.contactpicker.core.ContactPickerActivity;
import com.onegravity.contactpicker.group.Group;
import com.onegravity.contactpicker.picture.ContactPictureType;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class ContactListActivity extends AppCompatActivity {
    Button btnContact;
    private int REQUEST_CONTACT = 1;
    ContactAdapter contactAdapter;
    ListView contactList;
    ArrayList<ContactModel> contactsArrayList;
    int CONTACT_LIMIT = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactlistactivity);
        btnContact = findViewById(R.id.btnEditContactList);
        btnContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showContactListActivity();

            }
        });
        contactList = findViewById(R.id.lvContacts);
        contactsArrayList = DataProvider.getEmergencyContacts();
        contactAdapter = new ContactAdapter(this, R.layout.layout_contact, contactsArrayList);
        contactList.setAdapter(contactAdapter);
    }

    private void showContactListActivity() {

//        Intent intent = new Intent(this, ContactPickerActivity.class)
////                .putExtra(ContactPickerActivity.EXTRA_THEME, R.style.ContactPicker_Theme_Light)
//                .putExtra(ContactPickerActivity.EXTRA_CONTACT_BADGE_TYPE, ContactPictureType.ROUND.name())
//                .putExtra(ContactPickerActivity.EXTRA_SHOW_CHECK_ALL, true)
//                .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION, ContactDescription.ADDRESS.name())
//                .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION_TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
//                .putExtra(ContactPickerActivity.EXTRA_CONTACT_SORT_ORDER, ContactSortOrder.AUTOMATIC.name())
//                .putExtra(ContactPickerActivity.EXTRA_SELECT_CONTACTS_LIMIT,CONTACT_LIMIT)
//                .putExtra(ContactPickerActivity.EXTRA_ONLY_CONTACTS_WITH_PHONE,true);
//        startActivityForResult(intent, REQUEST_CONTACT);
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
        startActivityForResult(i, REQUEST_CONTACT);

//        picker?.pick()

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CONTACT && resultCode == Activity.RESULT_OK) {
            try {
                String phoneNo = null;
                String name = null;

                Uri uri = data.getData();
                Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                cursor.moveToFirst();
                int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                phoneNo = cursor.getString(phoneIndex);
                name = cursor.getString(nameIndex);

                Log.d("chech", "Name and Contact number is" + name + "," + phoneNo);
                ArrayList<ContactModel> selectedContacts=DataProvider.getEmergencyContacts();
                selectedContacts.add(new ContactModel(name,phoneNo));
                DataProvider.storeEmergencyContacts(selectedContacts);
                contactsArrayList=selectedContacts;
                contactAdapter.updateDataSet(contactsArrayList);
            } catch (Exception e) {
                e.printStackTrace();
            }


        } else {
            Log.e("Failed", "Not able to pick contact");
//    }
//            // we got a result from the contact picker
//
//            // process contacts
//            List<Contact> contacts = (List<Contact>) data.getSerializableExtra(ContactPickerActivity.RESULT_CONTACT_DATA);
//            ArrayList<ContactModel> selectedContacts=new ArrayList<ContactModel>();
//            for (Contact contact : contacts) {
//                // process the contacts...
//                Log.d("chech",contact.getPhone(0));
//
//                selectedContacts.add(new ContactModel(contact.getId(),contact.getFirstName()+" "+contact.getLastName(),contact.getPhone(0)));
////                Toast.makeText(this, contact.getFirstName(),Toast.LENGTH_SHORT).show();
//
//            }
//            if(selectedContacts.size()>0){
//                DataProvider.storeEmergencyContacts(selectedContacts);
//                contactsArrayList=selectedContacts;
//            }
//            contactAdapter.updateDataSet(contactsArrayList);
//
//            // process groups
//            List<Group> groups = (List<Group>) data.getSerializableExtra(ContactPickerActivity.RESULT_GROUP_DATA);
//            if(groups.size()>0){
//                Toast.makeText(this, "Please don't select groups", Toast.LENGTH_SHORT).show();
//            }
////            for (Group group : groups) {
////                // process the groups...
////            }
//
//        }
//
//    }
        }
    }
}
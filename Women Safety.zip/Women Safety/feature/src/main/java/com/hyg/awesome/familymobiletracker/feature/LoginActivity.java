package com.hyg.awesome.familymobiletracker.feature;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hyg.awesome.familymobiletracker.feature.Utilities.DataProvider;

import org.json.JSONException;
import org.json.JSONObject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    String url,server;
    EditText username,password;
    TextView tx,tx2;
    Button log;
    TextView signup;
    String name,userid;
    String qs="false";
    //ActionProcessButton login;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //server="192.168.1.6/project";
        server="womensafety.atwebpages.com";
        DataProvider.init(this);
        if(DataProvider.isLoggedIn()){
//            startLocationSenderService();
            Intent i=new Intent(LoginActivity.this,EmergencyAlertActivity.class);
            i.putExtra("server",server);
            i.putExtra("userid",DataProvider.getUserInfo());
            startActivity(i);
            finish();
        }
        setContentView(R.layout.activity_login);
        username=findViewById(R.id.etUsername);
        password=findViewById(R.id.editTextPassword);
//        tx=findViewById(R.id.textView);
//        tx2=findViewById(R.id.textView2);
        log=findViewById(R.id.cirLoginButton);
        signup=findViewById(R.id.tvSignup);
//        log.setMode(ActionProcessButton.Mode.ENDLESS);
        //signup.setMode();


        //server="192.168.1.6/project";
       // server="";



         log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                log.setProgress(50);
//                log.setText("Logging In");
                //log.setProgress();
                userLogin();
            }
        });
         signup.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent i=new Intent(LoginActivity.this,SignupActivity.class);
                 i.putExtra("server",server);
                 startActivity(i);
                 finish();
             }
         });
    }

public void userLogin(){
    url="http://"+server+"/login.php?username="+username.getText().toString()+"&password="+password.getText().toString();

    StringRequest req=new StringRequest(Request.Method.POST,url,new Response.Listener<String>(){

        @Override
        public void onResponse(String response) {
            try {
                Log.d("chech","Response received:"+response.toString());
                JSONObject obj=new JSONObject(response);
                Log.d("chech","object found");
                userid=obj.getString("userid");
                name=obj.getString("name");
                Log.d("chech",userid);
                qs=obj.getString("qs");
                //Toast.makeText(MainActivity.this,"Welcome, "+name,Toast.LENGTH_LONG).show();

            } catch (JSONException e) {
                Log.d("chech","string not found");
                e.printStackTrace();
            }
            if(qs.equals("true")){
                log.setText("Success");
//                log.setProgress(100);
                DataProvider.storeLoginInfo(userid);
//                startLocationSenderService();
                Intent i=new Intent(LoginActivity.this,EmergencyAlertActivity.class);
                i.putExtra("server",server);
                i.putExtra("userid",userid);
                startActivity(i);
                finish();
            }else{
                Toast.makeText(LoginActivity.this,"Error, Please try again ",Toast.LENGTH_LONG).show();
                log.setText("Try Again");
//                log.setProgress(-1);
            }
        }
    },new Response.ErrorListener(){

        @Override
        public void onErrorResponse(VolleyError error) {
        Log.d("chech",error.toString());
        }
    });
    RequestQueue rq= Volley.newRequestQueue(LoginActivity.this);
    rq.add(req);
    req.setRetryPolicy(new DefaultRetryPolicy(5000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

}

    public void startLocationSenderService() {
        Intent i=new Intent(LoginActivity.this,LocationSenderService.class);
        i.putExtra("name",name);
        i.putExtra("userid",DataProvider.getUserInfo());
        i.putExtra("server",server);
        startService(i);
    }
}

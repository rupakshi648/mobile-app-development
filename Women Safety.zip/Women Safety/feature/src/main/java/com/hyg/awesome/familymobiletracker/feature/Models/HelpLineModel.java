package com.hyg.awesome.familymobiletracker.feature.Models;

public class HelpLineModel {
    String name;

    public HelpLineModel(String name, String contact) {
        this.name = name;
        this.contact = contact;
    }

    String contact;

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }
}

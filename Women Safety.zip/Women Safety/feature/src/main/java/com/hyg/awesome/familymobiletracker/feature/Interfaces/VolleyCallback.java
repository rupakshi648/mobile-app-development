package com.hyg.awesome.familymobiletracker.feature.Interfaces;

public interface VolleyCallback{
    void onSuccess(String result);
}
